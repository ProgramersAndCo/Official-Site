import time
a1 = 'Gdje si!'
a2 = 'Aj vidimo se!'
print (a1)
time.sleep (2)
print (a2)