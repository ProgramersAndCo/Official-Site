import random

while True:
    user_input = input("What would you like to do? (Play/Quit) ")
    if user_input.lower() == "play":
        print("Great! Let's play a game")
        choices = input("Rock, Paper, Scissors? ")
        computer_choice = random.choice(["rock", "paper", "scissors"])
        if choices.lower() == computer_choice:
            print("It's a tie!")
        elif (choices.lower() == "rock" and computer_choice == "scissors") or (choices.lower() == "paper" and computer_choice == "rock") or (choices.lower() == "scissors" and computer_choice == "paper"):
            print("You win!")
        else:
            print("You lose!")
    elif user_input.lower() == "quit":
        print("Thanks for playing. See you next time!")
        break
    else:
        print("Invalid input. Please enter 'play' or 'quit'.")