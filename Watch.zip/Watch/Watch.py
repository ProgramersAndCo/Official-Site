from tkinter import *
from tkinter.ttk import *

from time import strftime

window = Tk()
window.title("Sat")

def time():
    string = strftime('%H:%M:%S')
    label.config(text=string)
    label.after(1000, time)
label = Label(window, font=("italic", 40), background = "black", foreground = "green")
label.pack(anchor='center')
time()

mainloop()